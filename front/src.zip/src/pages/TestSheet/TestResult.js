import React from "react";

function TestResult() {
  return <div></div>;
}

export default TestResult;
